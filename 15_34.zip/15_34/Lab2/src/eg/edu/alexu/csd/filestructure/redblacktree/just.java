package eg.edu.alexu.csd.filestructure.redblacktree;

import static org.junit.Assert.*;

import org.junit.Test;

public class just {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
