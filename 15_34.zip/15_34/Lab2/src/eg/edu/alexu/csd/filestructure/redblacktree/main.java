package eg.edu.alexu.csd.filestructure.redblacktree;

public class main {

	public static void main(String[] args) throws CloneNotSupportedException {
		RedBlackTree tree = new RedBlackTree();
		RBTreePrinter pr = new RBTreePrinter();
		ITreeMap map = new TreeMap();
/*		map.put(10, 52);
		map.put(18, 4);
		map.put(7, 100);
		map.remove(10);*/
		tree.insert(15, 4);
		tree.insert(16, 5);
		tree.insert(30, 6);
		tree.insert(25, 7);
/*		tree.insert(40, 8);
		tree.insert(60, 9);
		tree.insert(2, 10);
		tree.insert(1,11);
		tree.insert(70, 12);*/
//		pr.print(tree.getRoot());
//		System.out.println(tree.search(60));
	}

}
